<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Umfrage | 1</title> 
    <link rel="stylesheet" href="../assets/css/style.css">
  </head>
  <body>
    <span class="button" id="toggle-login">M133</span>
	<div id="formular">
	  <div id="triangle"></div>
	  <h1>
	  	<img class="umfragebild" src="../assets/images/umfrage.jpg" >
	  	Umfrage (1/3)
	  </h1>
	  <form action="../controller/umfrage01zu02.php" method="post">
	  	E-Mail:
	    <input type="email" name="benutzer" placeholder="E-Mail" required="required"/>
	    Passwort:
	    <input type="password" name="password" placeholder="Password" required="required"/>
	    <input type="submit" value="weiter >" />
	  </form>
	</div>
    <script src="../assets/js/index.js"></script>         
  </body>
</html>
